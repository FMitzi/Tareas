#include<stdlib.h>
#include<stdio.h>
#include<string.h>

//Imprime una cadena de caracteres por separado
int main(int argc, char *argv[]){
	/*
	int i;
	char *num=argv[1];
	
	fprintf(stdout, "arg[1]=%s\n", argv[1]);
	
	for(i=0; i<strlen(argv[1]); i++){
		fprintf(stdout, "num[%d]=%c \n", i, num[i]);
	}*/
	
	int i, j;
	char *num=argv[1];
	
	for(j=0; j<=argc; j++)
		fprintf(stdout, "arg[%d]=%s \n", j, argv[j]);

	for(i=0; i<strlen(argv[1]); i++){
		fprintf(stdout, "num[%d]=%c \n", i, num[i]);
		
	}

		
	return 0;
}

