//cdlist main

#include <stdio.h>
#include "cdlist.h"

// Funci�n que destruye los datos
void destroy_data(void *data) {
    free(data);
}

int main() {
    CDList list;
    CDListNode *node;
    int *data;
    int i;

    //Inicializar la lista
    cdlist_init(&list, destroy_data);

    //Insertar algunos elementos en la lista
    for (i = 1; i <= 5; i++) {
        if ((data = (int *)malloc(sizeof(int))) == NULL) {
            return 1;
        }
        *data = i;
        if (cdlist_ins_next(&list, cdlist_head(&list) != NULL ? cdlist_head(&list)->prev : NULL, data) != 0) {
            return 1;
        }
    }

    //Imprimir los elementos de la lista
    printf("Elementos en la lista: ");
    node = cdlist_head(&list);
    for (i = 0; i < cdlist_size(&list); i++) {
        printf("%d ", *(int *)cdlist_data(node));
        node = cdlist_next(node);
    }
    printf("\n");

    //Eliminar todos los elementos
    node = cdlist_head(&list);
    while (cdlist_size(&list) > 0) {
        cdlist_remove(&list, node, (void **)&data);
        free(data);
        node = cdlist_head(&list);
    }

    //Destruir la lista
    cdlist_destroy(&list);

    return 0;
}
