//cdlist.h

#ifndef CDLIST_H
#define CDLIST_H

#include <stdlib.h>

//Nodo de lista circular doblemente ligada
typedef struct CDListNode_ {
    void *data;
    struct CDListNode_ *next;
    struct CDListNode_ *prev;
} CDListNode;

//Estructura para la lista circular doblemente ligada
typedef struct CDList_ {
    int size;
    void (*destroy)(void *data);
    CDListNode *head;
} CDList;

//Interfaces p�blicas
void cdlist_init(CDList *list, void (*destroy)(void *data));
void cdlist_destroy(CDList *list);
int cdlist_ins_next(CDList *list, CDListNode *node, const void *data);
int cdlist_ins_prev(CDList *list, CDListNode *node, const void *data);
int cdlist_remove(CDList *list, CDListNode *node, void **data);

//Macros
#define cdlist_size(list) ((list)->size)
#define cdlist_head(list) ((list)->head)
#define cdlist_is_head(node) ((node) == (node)->next ? 1 : 0)
#define cdlist_is_tail(node) ((node) == (node)->prev ? 1 : 0)
#define cdlist_data(node) ((node)->data)
#define cdlist_next(node) ((node)->next)
#define cdlist_prev(node) ((node)->prev)

#endif

/*CDListNode: Estructura de un nodo en la lista circular doblemente ligada. Incluye punteros a los nodos next y prev.

CDList: Estructura para la lista, que incluye un puntero a la cabeza de la lista, el tama�o y un puntero a la funci�n de destrucci�n de los datos.

Funciones de la lista: cdlist_init, cdlist_destroy, cdlist_ins_next, cdlist_ins_prev y cdlist_remove son las interfaces p�blicas para manipular la lista.

Macros: Definen funciones comunes como obtener el tama�o de la lista, la cabeza de la lista, verificar si un nodo es la cabeza o la cola, y acceder a los datos y nodos adyacentes.
*/
  
